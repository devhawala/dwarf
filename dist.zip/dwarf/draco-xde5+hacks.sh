#!/bin/sh
#
# run dwarf mesa machine emulator
#
java -jar dwarf.jar -draco xde5.0_2xTajo+hacks $*
