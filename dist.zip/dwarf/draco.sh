#!/bin/sh
#
# run dwarf mesa machine emulator
#
java -jar dwarf.jar -draco $*
