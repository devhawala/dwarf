#!/bin/sh
#
# run dwarf mesa machine emulator
#
java -jar dwarf.jar $1 $2 $3 $4 $5 $6 $7 $8 $9 gvwin
